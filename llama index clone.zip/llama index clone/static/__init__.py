# Empty initialization file for static directory
