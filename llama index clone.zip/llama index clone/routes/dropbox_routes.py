from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import logging
import os
import tempfile
from uuid import uuid4
from utils.dropbox_handler import download_file_from_dropbox
import mimetypes

router = APIRouter()
logger = logging.getLogger(__name__)

class DropboxURL(BaseModel):
    url: str

def get_filename_from_url(url: str) -> str:
    return url.split("/")[-1]

@router.post("/process_dropbox_url")
async def process_dropbox_url(request: DropboxURL):
    try:
        url = request.url
        logger.info(f"Processing URL: {url}")
        
        if not url or "dropboxusercontent.com" not in url:
            raise HTTPException(status_code=400, detail="Not a valid Dropbox URL")
        
        # Create download directory
        download_dir = os.path.join("uploads", "dropbox")
        os.makedirs(download_dir, exist_ok=True)
        
        # Create unique filename
        temp_filename = f"download_{uuid4().hex}"
        output_path = os.path.join(download_dir, temp_filename)
        
        # Download the file
        success = await download_file_from_dropbox(url, output_path)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to download file")
            
        if not os.path.exists(output_path):
            raise HTTPException(status_code=500, detail="Download failed - file not found")
            
        # Get file info
        file_size = os.path.getsize(output_path)
        if file_size == 0:
            os.remove(output_path)
            raise HTTPException(status_code=500, detail="Downloaded file is empty")
        
        content_type, _ = mimetypes.guess_type(output_path)
        logger.info(f"Downloaded file: {output_path} ({file_size} bytes, {content_type})")
        
        return {
            "status": "success",
            "session_id": uuid4().hex,
            "filename": os.path.basename(output_path),
            "file_path": output_path,
            "content_type": content_type or "application/octet-stream",
            "file_size": file_size
        }
        
    except HTTPException as he:
        raise he
    except Exception as e:
        logger.error(f"Error processing Dropbox URL: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
