import streamlit as st
from answer_from_Temp import direct_response_from_template
from direct_response import direct_response_search_and_solve as direct_response_search_and_solve
# Constants for API configuration
API_KEY = "your_api_key"
BASE_URL = "https://6kejhkzn26gvxb-11434.proxy.runpod.net/v1"
models_config = {
                 "Fused LLaMA 70B": {
                     "model": "llama3.3:latest",
                     "api_key": API_KEY,
                     "base_url_1": 'https://unknown-veronique-finsocialdigitalsystem-cf02d63f.koyeb.app/v1',
                     "base_url_2": BASE_URL
                 },
                 "basic-reasioning-get": {
                     "model": "llama3.2:1b",
                     "api_key": API_KEY,
                     "base_url_1": BASE_URL
                 },
                 "Fused Gemma 12B": {
                     "model": "gemma3:12b",
                     "api_key": API_KEY,
                     "base_url_1": 'https://unknown-veronique-finsocialdigitalsystem-cf02d63f.koyeb.app/v1',
                     "base_url_2": BASE_URL
                 },
    }
# Custom stylin
st.set_page_config(
    page_title="Finsocial Digital Systems - Query Assistant",
    page_icon="💡",
    layout="wide"
)

def main():
    # Sidebar branding
    with st.sidebar:
        st.image("./logo.png", width=150)  # Replace with actual logo
        st.title("Finsocial Digital")
        st.markdown("---")
        model = st.selectbox(
            "Select Model",
            ["Fused LLaMA 70B", "Fused Gemma 12B"],
            index=0
        )
        st.markdown("---")
    
    # Main area
    # Add CSS animation for title
    st.markdown(
        """
        <style>
        .fade-in-text {
            animation: fadeIn 2s ease-in-out;
        }
        
        @keyframes fadeIn {
            0% { opacity: 0; transform: translateY(-20px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        </style>
        """, unsafe_allow_html=True)
    st.markdown('<h1 class="fade-in-text">Finsocial Digital Digital Systems AI Assistant</h1>', unsafe_allow_html=True)
    st.markdown("### Your Smart Query Solutions Partner")
    
    # Chat interface
    query = st.text_area("How can I help you today?", height=100)
    
    if st.button("Get Response", type="primary"):
        if query:
            with st.spinner("Generating response..."):
                try:
                    import concurrent.futures

                    with concurrent.futures.ThreadPoolExecutor() as executor:
                        future_template = executor.submit(
                            direct_response_from_template,
                            query=query,
                            model=models_config[model]['model'],
                            api_key=models_config[model]['api_key'],
                            base_url=models_config[model]['base_url_1']
                        )
                        future_direct = executor.submit(
                            direct_response_search_and_solve,
                            query=query,
                            model=models_config[model]['model'],
                            api_key=models_config[model]['api_key'],
                            base_url=models_config[model]['base_url_1']
                        )

                        results = future_template.result()
                        direct_model_Response = future_direct.result()
                    
                    st.markdown("---")
                    st.markdown("### Direct Model Response :")
                    st.write(direct_model_Response)
                    st.markdown("### Enchanced Response:")
                    st.write(results)
                    
                except Exception as e:
                    st.error(f"Error: {str(e)}")
        else:
            st.warning("Please enter a query first.")
    
    # Footer
    st.markdown("---")
    st.markdown(
        "<div style='text-align: center; color: grey;'>"
        "© 2025 Finsocial Digital Systems. All rights reserved."
        "</div>", 
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()
