from fastapi import FastAPI, Request, File, UploadFile, HTTPException, Form, BackgroundTasks, Security, Depends
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
import os
import uuid
import uvicorn
from utils.file_processor import process_file
from utils.ollama_client import get_ollama_response
from typing import Dict, Optional, Any
import shutil
import logging
import json
from starlette.middleware.sessions import SessionMiddleware
from pydantic import BaseModel
import asyncio
import concurrent.futures
import time
import requests
from dotenv import load_dotenv
from fastapi.security import APIKeyHeader
import mimetypes
import magic

# Load environment variables from .env file
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Document Q&A Tool")
# Use a longer maxAge for sessions to ensure they don't expire too quickly
app.add_middleware(
    SessionMiddleware, 
    secret_key="your-very-long-and-secure-secret-key-here-12345",
    max_age=3600,  # 1 hour
    same_site="lax",  # Less restrictive same-site policy
    https_only=False  # Set to True in production with HTTPS
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Create a folder for temporary session storage
SESSION_STORAGE = "session_storage"
os.makedirs(SESSION_STORAGE, exist_ok=True)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Define request models
class UrlRequest(BaseModel):
    url: str

class QueryRequest(BaseModel):
    question: str
    session_id: Optional[str] = None

# Define API key header for session management
API_KEY_HEADER = APIKeyHeader(name="X-Session-ID", auto_error=False)

# New function to download file from Dropbox
async def download_file_from_dropbox(url: str) -> tuple:
    """
    Download a file from a Dropbox URL
    
    Args:
        url (str): Dropbox URL
        
    Returns:
        tuple: (filepath, filename) where the file was saved
    """
    try:
        logger.info(f"Downloading file from Dropbox URL: {url}")
        
        # Convert the URL from dl=0 to dl=1 to force download
        if 'dl=0' in url:
            direct_download_url = url.replace('dl=0', 'dl=1')
        else:
            direct_download_url = url + '&dl=1' if '?' in url else url + '?dl=1'
        
        logger.info(f"Direct download URL: {direct_download_url}")
        
        # Extract the filename from the URL
        filename = url.split('/')[-1].split('?')[0]
        if not filename or filename == "":
            filename = f"dropbox_file_{uuid.uuid4()}"
        
        # Create a unique filename to avoid collisions
        unique_filename = f"{uuid.uuid4()}_{filename}"
        filepath = os.path.join(UPLOAD_FOLDER, unique_filename)
        
        # Download the file
        response = requests.get(direct_download_url, stream=True, timeout=60)
        
        if response.status_code != 200:
            logger.error(f"Failed to download file. Status code: {response.status_code}")
            raise HTTPException(status_code=response.status_code, 
                               detail=f"Failed to download file from Dropbox. Status code: {response.status_code}")
        
        # Save the file
        with open(filepath, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:  # Filter out keep-alive new chunks
                    f.write(chunk)
        
        logger.info(f"File downloaded successfully to: {filepath}")
        return filepath, filename
        
    except Exception as e:
        logger.error(f"Error downloading file from Dropbox: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error downloading file from Dropbox: {str(e)}")

@app.post("/upload-from-dropbox")
async def upload_from_dropbox(url_request: UrlRequest, request: Request):
    """
    Download a file from a Dropbox URL and process it like an uploaded file
    """
    try:
        logger.info(f"Received Dropbox URL: {url_request.url}")
        
        # Validate the URL (basic check)
        if not url_request.url.startswith("https://www.dropbox.com/"):
            raise HTTPException(status_code=400, detail="Invalid Dropbox URL")
        
        # Download the file from Dropbox
        filepath, original_filename = await download_file_from_dropbox(url_request.url)
        
        # Process the downloaded file using the same function as file uploads
        return await process_saved_file(filepath, original_filename, request)
        
    except HTTPException as he:
        logger.error(f"HTTP Exception: {he.detail}")
        raise he
    except Exception as e:
        logger.error(f"Unexpected error in Dropbox download: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

@app.post("/upload")
async def upload_file(file: UploadFile = File(...), request: Request = None):
    try:
        logger.info(f"Received file: {file.filename}")
        
        if not file.filename:
            raise HTTPException(status_code=400, detail="No selected file")
        
        # Create a secure filename
        filename = f"{uuid.uuid4()}_{file.filename}"
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        
        # Save the file
        try:
            with open(filepath, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)
            logger.info(f"File saved to {filepath}")
        except Exception as e:
            logger.error(f"File save error: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Could not save file: {str(e)}")
        
        return await process_saved_file(filepath, file.filename, request)
    
    except HTTPException as he:
        logger.error(f"HTTP Exception: {he.detail}")
        raise he
    except Exception as e:
        logger.error(f"Unexpected error in upload: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

async def process_saved_file(filepath: str, original_filename: str, request: Request):
    """Common function to process a saved file and update session"""
    try:
        # Ensure the file exists
        if not os.path.exists(filepath):
            logger.error(f"File not found: {filepath}")
            raise HTTPException(status_code=500, detail="File not found after download")

        # Check file type
        content_type, _ = mimetypes.guess_type(filepath)
        file_extension = os.path.splitext(filepath)[1].lower()
        
        # Create session storage subdirectories
        images_dir = os.path.join(SESSION_STORAGE, "images")
        docs_dir = os.path.join(SESSION_STORAGE, "documents")
        os.makedirs(images_dir, exist_ok=True)
        os.makedirs(docs_dir, exist_ok=True)
        
        # Generate session ID early
        session_id = str(uuid.uuid4())
        
        # Define known image extensions
        image_extensions = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'}
        is_image = file_extension in image_extensions or (content_type and 'image' in content_type)
        is_media_file = file_extension in ['.mp3', '.mp4', '.wav', '.avi', '.mkv', '.m4a', '.flac', '.ogg', '.webm']
        
        logger.info(f"Processing file: {filepath} (Image: {is_image}, Media: {is_media_file})")
        
        try:
            if is_image:
                # Copy image to session storage with session ID
                dest_path = os.path.join(images_dir, f"{session_id}{file_extension}")
                shutil.copy2(filepath, dest_path)
                content = f"IMAGE_FILE:{dest_path}"
                logger.info(f"Image copied to: {dest_path}")
            else:
                # Process other file types
                content = process_file(filepath)
            
            # Save content to session file
            session_file = os.path.join(SESSION_STORAGE, f"{session_id}.txt")
            with open(session_file, "w", encoding="utf-8") as f:
                f.write(content)
            
            # Update session data
            request.session["session_id"] = session_id
            request.session["filename"] = original_filename
            request.session["file_type"] = "image" if is_image else "media" if is_media_file else "document"
            request.session["file_path"] = dest_path if is_image else filepath
            
            logger.info(f"Session created: {session_id}")
            
            return JSONResponse(
                content={
                    "message": f"File processed successfully",
                    "content_preview": "Image file processed" if is_image else (content[:200] + "..." if len(content) > 200 else content),
                    "session_id": session_id,
                    "file_type": request.session["file_type"]
                },
                headers={"Set-Cookie": "session_active=true; Path=/; SameSite=Lax"}
            )
            
        finally:
            # Clean up original file if it's in uploads folder
            if os.path.dirname(filepath) == UPLOAD_FOLDER and os.path.exists(filepath):
                os.remove(filepath)
                logger.info(f"Cleaned up original file: {filepath}")
                
    except Exception as e:
        logger.error(f"Error processing file: {str(e)}")
        # Clean up any partial files
        if os.path.exists(filepath):
            os.remove(filepath)
        raise HTTPException(status_code=500, detail=f"File processing error: {str(e)}")

@app.get("/check_session", response_class=JSONResponse)
async def check_session(request: Request):
    session_data = dict(request.session)
    logger.info(f"Checking session: {session_data}")
    
    if "session_id" in request.session:
        return {"status": "active", "session_id": request.session["session_id"]}
    else:
        return {"status": "inactive"}

# Helper function to get session ID from either cookie or header
async def get_session_id(
    request: Request,
    api_key: str = Security(API_KEY_HEADER)
) -> str:
    """
    Get session ID from either the session cookie or the X-Session-ID header.
    Returns None if no session ID is found.
    """
    # First check for API key in header
    if api_key:
        return api_key
    
    # Then check for session in cookie
    if "session_id" in request.session:
        return request.session["session_id"]
    
    return None

@app.post("/query")
async def query(
    request: Request,
    query_request: QueryRequest,
    session_id_from_header: str = Depends(get_session_id)
):
    try:
        # Use session_id from request body if provided, otherwise use from header/cookie
        session_id = query_request.session_id or session_id_from_header
        
        # Log the request
        logger.info(f"Received query request with session ID: {session_id}")
        
        # Check if session_id exists
        if not session_id:
            logger.error("No session_id provided")
            raise HTTPException(status_code=400, detail="No session ID provided. Please upload a file first or provide a valid session ID.")
        
        session_file = os.path.join(SESSION_STORAGE, f"{session_id}.txt")
        
        # Check if session file exists
        if not os.path.exists(session_file):
            logger.error(f"Session file not found: {session_file}")
            raise HTTPException(status_code=400, detail="Session data not found, please upload file again")
        
        # Load file content from session file
        with open(session_file, "r", encoding="utf-8") as f:
            file_content = f.read()
        
        user_question = query_request.question
        
        # Get filename from session if it exists
        filename = request.session.get("filename", "uploaded file") if hasattr(request, "session") else "uploaded file"
        
        # Check if this is an image file
        is_image = file_content.startswith("IMAGE_FILE:")
        if is_image:
            logger.info(f"Processing image question for file in session: {session_id}")
            # For images, the file_content contains the path to the image file
            image_path = file_content.replace("IMAGE_FILE:", "").strip()
            
            # Verify the image file exists
            if not os.path.exists(image_path):
                logger.error(f"Image file not found: {image_path}")
                raise HTTPException(status_code=404, detail="Image file not found")
        else:
            logger.info(f"Processing question about file in session: {session_id}")
        
        # Get response from Ollama
        try:
            response = get_ollama_response(user_question, file_content)
            logger.info("Got response from Ollama successfully")
            return JSONResponse(content={"response": response})
        except Exception as e:
            logger.error(f"Ollama API error: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error getting response: {str(e)}")
    
    except HTTPException as he:
        raise he
    except Exception as e:
        logger.error(f"Unexpected error in query: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

@app.get("/api/health")
async def health_check():
    """Health check endpoint to verify API connectivity"""
    try:
        # Check if Ollama API is reachable
        from utils.ollama_client import OLLAMA_API_URL
        
        try:
            # Try to connect to Ollama API
            response = requests.get(f"{OLLAMA_API_URL}/api/version", timeout=500)
            ollama_status = "up" if response.status_code == 200 else "down"
            ollama_version = response.json().get("version", "unknown") if response.status_code == 200 else "unknown"
        except Exception as e:
            logger.error(f"Error connecting to Ollama API: {str(e)}")
            ollama_status = "down"
            ollama_version = str(e)
        
        return {
            "status": "healthy",
            "version": "1.0.0",
            "ollama_api": {
                "url": OLLAMA_API_URL,
                "status": ollama_status,
                "version": ollama_version
            },
            "environment": os.environ.get("ENVIRONMENT", "development")
        }
    except Exception as e:
        logger.error(f"Health check error: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={"status": "unhealthy", "error": str(e)}
        )

@app.get("/api/session/{session_id}/status")
async def get_session_status(session_id: str):
    """Check if a specific session exists"""
    session_file = os.path.join(SESSION_STORAGE, f"{session_id}.txt")
    if os.path.exists(session_file):
        # Get basic info about the session file
        file_stats = os.stat(session_file)
        creation_time = file_stats.st_ctime
        size = file_stats.st_size
        
        return {
            "status": "active",
            "session_id": session_id,
            "created": creation_time,
            "size_bytes": size
        }
    else:
        return {"status": "inactive", "message": "Session not found"}

if __name__ == "__main__":
    uvicorn.run("app:app", port=5000, reload=True)