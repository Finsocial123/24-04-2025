import argparse
import requests
import os
import sys
import json
from typing import Optional, Dict, Any
import time
from pathlib import Path

BASE_URL = "http://127.0.0.1:5000"
SESSION_FILE = ".session_data.json"

def save_session(session_id: str, filename: Optional[str] = None):
    """Save session ID to a file"""
    with open(SESSION_FILE, "w") as f:
        json.dump({
            "session_id": session_id,
            "filename": filename,
            "timestamp": time.time()
        }, f)
    print(f"Session saved: {session_id}")

def load_session() -> Optional[Dict[str, Any]]:
    """Load session data if available"""
    if not os.path.exists(SESSION_FILE):
        return None
    
    try:
        with open(SESSION_FILE, "r") as f:
            data = json.load(f)
            # Check session on server
            response = requests.get(f"{BASE_URL}/api/session/{data['session_id']}/status")
            if response.status_code == 200 and response.json().get("status") == "active":
                return data
            else:
                print("Previous session expired or not found on server.")
                return None
    except Exception as e:
        print(f"Error loading session: {str(e)}")
        return None

def upload_file(filepath: str) -> Optional[str]:
    """Upload a file to the API"""
    if not os.path.exists(filepath):
        print(f"Error: File {filepath} not found")
        return None
    
    print(f"Uploading file: {filepath}...")
    
    try:
        with open(filepath, "rb") as f:
            filename = os.path.basename(filepath)
            files = {"file": (filename, f)}
            response = requests.post(f"{BASE_URL}/upload", files=files)
            
            if response.status_code != 200:
                print(f"Error: {response.json().get('detail', 'Unknown error')}")
                return None
            
            result = response.json()
            session_id = result.get("session_id")
            
            if session_id:
                save_session(session_id, filename)
                print(f"File {filename} uploaded and processed successfully.")
                return session_id
            else:
                print("Error: No session ID returned from server")
                return None
                
    except Exception as e:
        print(f"Error uploading file: {str(e)}")
        return None

def process_url(url_type: str, url: str) -> Optional[str]:
    """Process a URL (youtube, dropbox, or generic)"""
    print(f"Processing {url_type} URL: {url}...")
    
    try:
        endpoint = f"/process_{url_type}_url"
        response = requests.post(
            f"{BASE_URL}{endpoint}",
            json={"url": url}
        )
        
        if response.status_code != 200:
            print(f"Error: {response.json().get('detail', 'Unknown error')}")
            return None
            
        result = response.json()
        session_id = result.get("session_id")
        
        if session_id:
            save_session(session_id, url)
            print(f"{url_type.capitalize()} URL processed successfully.")
            return session_id
        else:
            print("Error: No session ID returned from server")
            return None
            
    except Exception as e:
        print(f"Error processing URL: {str(e)}")
        return None

def ask_question(question: str, session_id: Optional[str] = None) -> bool:
    """Ask a question about the uploaded document"""
    if not session_id:
        session_data = load_session()
        if not session_data:
            print("Error: No active session. Please upload a file or process a URL first.")
            return False
        session_id = session_data["session_id"]
    
    print(f"Asking: {question}")
    print("Waiting for response...")
    
    try:
        headers = {"X-Session-ID": session_id}
        response = requests.post(
            f"{BASE_URL}/query",
            json={"question": question},
            headers=headers
        )
        
        if response.status_code != 200:
            print(f"Error: {response.json().get('detail', 'Unknown error')}")
            return False
            
        result = response.json()
        print("\n" + "-" * 80)
        print(f"Answer: {result['response']}")
        print("-" * 80 + "\n")
        return True
        
    except Exception as e:
        print(f"Error asking question: {str(e)}")
        return False

def check_health() -> bool:
    """Check the health of the API"""
    try:
        response = requests.get(f"{BASE_URL}/api/health")
        if response.status_code != 200:
            print("API health check failed")
            return False
        
        health_data = response.json()
        
        print("\nAPI Health Status:")
        print(f"Status: {health_data.get('status', 'Unknown')}")
        print(f"Version: {health_data.get('version', 'Unknown')}")
        
        ollama_api = health_data.get('ollama_api', {})
        print(f"Ollama API: {ollama_api.get('status', 'Unknown')}")
        print(f"Ollama URL: {ollama_api.get('url', 'Unknown')}")
        print(f"Environment: {health_data.get('environment', 'Unknown')}")
        
        return ollama_api.get('status', 'Unknown') == 'up'
    except Exception as e:
        print(f"Error checking API health: {str(e)}")
        return False

def interactive_mode():
    """Run in interactive mode where the user can enter commands"""
    session_data = load_session()
    if session_data:
        print(f"Active session found for: {session_data.get('filename', 'Unknown file')}")
    
    while True:
        print("\n" + "=" * 40)
        print("Document Q&A CLI Tool")
        print("=" * 40)
        print("1. Upload a file")
        print("2. Process a YouTube URL")
        print("3. Process a Dropbox URL")
        print("4. Process any URL")
        print("5. Ask a question")
        print("6. Check API health")
        print("7. Clear current session")
        print("8. Exit")
        print("=" * 40)
        
        choice = input("Enter your choice (1-8): ").strip()
        
        if choice == "1":
            filepath = input("Enter the path to the file: ").strip()
            upload_file(filepath)
        
        elif choice == "2":
            url = input("Enter YouTube URL: ").strip()
            process_url("youtube", url)
        
        elif choice == "3":
            url = input("Enter Dropbox URL: ").strip()
            process_url("dropbox", url)
        
        elif choice == "4":
            url = input("Enter any URL: ").strip()
            process_url("generic", url)
        
        elif choice == "5":
            session_data = load_session()
            if not session_data:
                print("No active session. Please upload a file or process a URL first.")
                continue
                
            print(f"Current document: {session_data.get('filename', 'Unknown file')}")
            question = input("Enter your question: ").strip()
            if question:
                ask_question(question, session_data["session_id"])
        
        elif choice == "6":
            check_health()
        
        elif choice == "7":
            if os.path.exists(SESSION_FILE):
                os.remove(SESSION_FILE)
                print("Session cleared.")
            else:
                print("No active session found.")
                
        elif choice == "8":
            print("Goodbye!")
            break
        
        else:
            print("Invalid choice. Please try again.")

def main():
    """Main function to parse arguments and execute commands"""
    parser = argparse.ArgumentParser(description="Command-line tool to interact with Document Q&A API")
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Upload file command
    upload_parser = subparsers.add_parser("upload", help="Upload a file")
    upload_parser.add_argument("filepath", help="Path to the file to upload")
    
    # Process URL commands
    youtube_parser = subparsers.add_parser("youtube", help="Process YouTube URL")
    youtube_parser.add_argument("url", help="YouTube URL")
    
    dropbox_parser = subparsers.add_parser("dropbox", help="Process Dropbox URL")
    dropbox_parser.add_argument("url", help="Dropbox URL")
    
    url_parser = subparsers.add_parser("url", help="Process any URL")
    url_parser.add_argument("url", help="URL to process")
    
    # Ask question command
    question_parser = subparsers.add_parser("ask", help="Ask a question")
    question_parser.add_argument("question", help="Question to ask")
    question_parser.add_argument("--session", help="Optional session ID")
    
    # Health check command
    subparsers.add_parser("health", help="Check API health")
    
    # Interactive mode (no args)
    if len(sys.argv) == 1:
        interactive_mode()
        return
    
    args = parser.parse_args()
    
    # Execute the appropriate command
    if args.command == "upload":
        upload_file(args.filepath)
    
    elif args.command == "youtube":
        process_url("youtube", args.url)
    
    elif args.command == "dropbox":
        process_url("dropbox", args.url)
    
    elif args.command == "url":
        process_url("generic", args.url)
    
    elif args.command == "ask":
        ask_question(args.question, args.session)
    
    elif args.command == "health":
        check_health()

if __name__ == "__main__":
    main()
