import os
import json
import sys
import uuid
from datetime import datetime

# Try to import the language information from the translator module
try:
    from translator import get_supported_languages, show_language_menu
    has_translator = True
except ImportError:
    has_translator = False

# Import functionality from HindAI
try:
    from HindAI import process_message_and_get_response
    has_hindai = True
except ImportError:
    has_hindai = False
    print("Warning: HindAI module not found. Response generation will be disabled.")

def sanitize_filename(filename):
    """Sanitize filename to ensure it's valid for filesystem operations"""
    # Replace any characters that might be problematic in filenames
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    return filename

def get_user_chats(username):
    """
    Get all chats for a specific user
    
    Args:
        username (str): Username to search for
    
    Returns:
        list: List of dictionaries containing chat_id and first_message
    """
    base_path = "chat_histories"
    user_path = os.path.join(base_path, sanitize_filename(username))
    
    # Check if user directory exists
    if not os.path.exists(user_path):
        print(f"No chat history found for user '{username}'")
        return []
    
    chat_files = [f for f in os.listdir(user_path) if f.endswith('.json')]
    
    if not chat_files:
        print(f"No chat files found for user '{username}'")
        return []
    
    result = []
    
    for chat_file in chat_files:
        chat_id = os.path.splitext(chat_file)[0]  # Remove .json extension
        file_path = os.path.join(user_path, chat_file)
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                chat_data = json.load(f)
                
            # Find the first user message
            first_message = None
            first_timestamp = None
            
            for message in chat_data:
                if message.get("role") == "user":
                    if first_message is None or message.get("timestamp", "") < first_timestamp:
                        first_message = message.get("content", "")
                        first_timestamp = message.get("timestamp", "")
            
            # Add to results
            result.append({
                "chat_id": chat_id,
                "first_message": first_message,
                "timestamp": first_timestamp
            })
            
        except Exception as e:
            print(f"Error reading chat file {chat_file}: {e}")
    
    # Sort by timestamp, most recent first
    result.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
    return result

def format_timestamp(timestamp_str):
    """Format ISO timestamp to a more readable format"""
    if not timestamp_str:
        return "Unknown time"
    
    try:
        dt = datetime.fromisoformat(timestamp_str)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return timestamp_str

def display_user_chats(username):
    """Display all chats for a user in a formatted way"""
    chats = get_user_chats(username)
    
    if not chats:
        return
    
    print(f"\nFound {len(chats)} chat(s) for user '{username}':\n")
    print("=" * 80)
    
    for i, chat in enumerate(chats, 1):
        chat_id = chat.get("chat_id", "Unknown")
        first_message = chat.get("first_message", "No message found")
        timestamp = format_timestamp(chat.get("timestamp"))
        
        print(f"Chat #{i}")
        print(f"ID: {chat_id}")
        print(f"Time: {timestamp}")
        print(f"First message: {first_message[:100]}{'...' if len(first_message) > 100 else ''}")
        print("=" * 80)

def get_all_languages():
    """
    Get all supported languages with their codes
    
    Returns:
        list: List of dictionaries containing language name and code
    """
    # If we have direct access to translator module, use it
    if has_translator:
        try:
            return get_supported_languages()
        except:
            # If function not available but module is, try showing menu directly
            try:
                return show_language_menu(return_list=True)
            except:
                pass
    
    # Fallback to hardcoded common languages if translator module is unavailable
    return [
        {"name": "English", "code": "eng_Latn"},
        {"name": "Hindi", "code": "hin_Deva"},
        {"name": "Spanish", "code": "spa_Latn"},
        {"name": "French", "code": "fra_Latn"},
        {"name": "German", "code": "deu_Latn"},
        {"name": "Chinese (Simplified)", "code": "zho_Hans"},
        {"name": "Japanese", "code": "jpn_Jpan"},
        {"name": "Arabic", "code": "ara_Arab"},
        {"name": "Russian", "code": "rus_Cyrl"},
        {"name": "Portuguese", "code": "por_Latn"},
        {"name": "Bengali", "code": "ben_Beng"},
        {"name": "Urdu", "code": "urd_Arab"},
        {"name": "Telugu", "code": "tel_Telu"},
        {"name": "Tamil", "code": "tam_Taml"},
        {"name": "Marathi", "code": "mar_Deva"},
        {"name": "Kannada", "code": "kan_Knda"},
        {"name": "Gujarati", "code": "guj_Gujr"}
    ]

def display_all_languages():
    """Display all supported languages with their codes"""
    languages = get_all_languages()
    
    if not languages:
        print("No language information available")
        return
    
    print("\nSupported Languages:")
    print("=" * 50)
    
    # Calculate column width for formatting
    max_name_length = max(len(lang.get("name", "")) for lang in languages) + 2
    
    # Print header
    print(f"{'Language':<{max_name_length}} | Code")
    print("-" * max_name_length + "-+-" + "-" * 10)
    
    # Print each language
    for lang in sorted(languages, key=lambda x: x.get("name", "")):
        name = lang.get("name", "Unknown")
        code = lang.get("code", "")
        print(f"{name:<{max_name_length}} | {code}")
    
    print("=" * 50)

def get_chat_by_id(username, chat_id):
    """
    Get a specific chat by ID for a user
    
    Args:
        username (str): Username to search for
        chat_id (str): Chat ID to retrieve
    
    Returns:
        list: List of messages in the chat, or None if not found
    """
    base_path = "chat_histories"
    user_path = os.path.join(base_path, sanitize_filename(username))
    file_path = os.path.join(user_path, f"{sanitize_filename(chat_id)}.json")
    
    if not os.path.exists(file_path):
        print(f"No chat found with ID '{chat_id}' for user '{username}'")
        return None
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            chat_data = json.load(f)
        return chat_data
    except Exception as e:
        print(f"Error reading chat file: {e}")
        return None

def display_complete_chat(username, chat_id):
    """Display a complete chat conversation for a specific chat ID in a user-friendly format"""
    chat_data = get_chat_by_id(username, chat_id)
    
    if not chat_data:
        return
    
    print(f"\nComplete chat for user '{username}', chat ID '{chat_id}':\n")
    print("=" * 80)
    
    # Sort messages by timestamp if available
    if all("timestamp" in msg for msg in chat_data):
        chat_data.sort(key=lambda x: x.get("timestamp", ""))
    
    # Create a list to store processed messages for display
    display_messages = []
    
    # First pass: Process and combine messages
    current_exchange = {"timestamp": None, "user_msg": None, "ai_msg": None, "reasoning": None}
    
    for msg in chat_data:
        role = msg.get("role", "unknown")
        content = msg.get("content", "")
        timestamp = msg.get("timestamp", "")
        message_type = msg.get("message_type", "")
        
        # Check for reasoning process in system messages
        if role == "system" and message_type == "reasoning_process":
            # This is a reasoning message - associate with the current exchange
            if current_exchange["user_msg"] is not None:
                current_exchange["reasoning"] = content
            continue
            
        # Skip other system messages and tool requests
        if role == "system" or content == "[Tool request]":
            continue
        
        # Process user messages
        if role == "user":
            # If we have a previous exchange, add it to display messages
            if current_exchange["user_msg"] is not None:
                display_messages.append(current_exchange.copy())
            
            # Start a new exchange
            current_exchange = {
                "timestamp": timestamp,
                "user_msg": content,
                "ai_msg": None,
                "reasoning": None
            }
        
        # Process AI responses - we want the translated version when available
        elif role == "assistant":
            clean_content = content.replace("[Tool request]", "").strip()
            if clean_content and current_exchange["ai_msg"] is None:
                current_exchange["ai_msg"] = clean_content
        
        # Process translations - we want to replace AI messages with their translations
        elif role == "translate" and msg.get("direction") == "english_to_user":
            # This is a translated AI response - use this instead of the English version
            translated_content = content
            if translated_content and current_exchange["user_msg"] is not None:
                current_exchange["ai_msg"] = translated_content
    
    # Add the last exchange if it exists
    if current_exchange["user_msg"] is not None:
        display_messages.append(current_exchange)
    
    # Display the conversations in a clean format
    for exchange in display_messages:
        timestamp = format_timestamp(exchange["timestamp"])
        print(f"\nTime: {timestamp}")
        print(f"User: {exchange['user_msg']}")
        if exchange["ai_msg"]:
            print(f"HindAI: {exchange['ai_msg']}")
        if exchange["reasoning"]:
            print(f"Reasoning: {exchange['reasoning']}")
        print("-" * 80)
    
    print("\n" + "=" * 80)

def initiate_chat(username, message, language_code=None, language_name=None, get_response=False):
    """
    Initiate a new chat with a username and initial message
    
    Args:
        username (str): Username to create chat for
        message (str): Initial message for the chat
        language_code (str, optional): Language code for the chat
        language_name (str, optional): Language name for display
        get_response (bool): Whether to get an immediate response from HindAI
        
    Returns:
        tuple: (chat_id, response) where response is None if get_response is False
    """
    if not username or not message:
        print("Error: Username and message cannot be empty")
        return None, None
        
    # Generate a new chat ID
    chat_id = str(uuid.uuid4())
    
    # Create directory structure
    base_path = "chat_histories"
    user_path = os.path.join(base_path, sanitize_filename(username))
    os.makedirs(user_path, exist_ok=True)
    
    # File path for the new chat
    file_path = os.path.join(user_path, f"{sanitize_filename(chat_id)}.json")
    
    # Create initial message
    timestamp = datetime.now().isoformat()
    
    # Create chat data with initial message and language preference
    chat_data = [{
        "role": "user",
        "content": message,
        "timestamp": timestamp
    }]
    
    # Add language metadata if provided
    if language_code:
        chat_data.append({
            "role": "system",
            "content": "Language preference set",
            "timestamp": timestamp,
            "language_code": language_code,
            "language_name": language_name or "Unknown",
            "message_type": "language_preference"
        })
    
    try:
        # Save the initial chat file
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(chat_data, f, indent=2)
        
        print(f"\nChat initiated successfully for user '{username}'")
        print(f"Chat ID: {chat_id}")
        if language_code:
            print(f"Language: {language_name or language_code}")
        print(f"Initial message: {message}")
        
        # If requested and HindAI is available, get a response
        response = None
        if get_response and has_hindai:
            try:
                print("\nGenerating response from HindAI...")
                
                # Set global user_language in HindAI if language was specified
                if language_code and language_name:
                    try:
                        import HindAI
                        HindAI.user_language = {
                            "code": language_code,
                            "name": language_name
                        }
                    except:
                        pass
                
                # Simply call HindAI directly to generate the response
                # HindAI will generate the reasoning internally and add it to chat history
                response = process_message_and_get_response(username, message, chat_id)
                
                # Ensure we have a valid response
                if response and response.strip():
                    print("\nHindAI Response:")
                    print("-" * 80)
                    print(response)
                    print("-" * 80)
                else:
                    print("\nWarning: Received empty response from HindAI.")
                    print("Checking chat file for potential response...")
                    
                    # Try to get the response from the chat file directly
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            updated_chat = json.load(f)
                            
                        # Find the most recent assistant message
                        for msg in reversed(updated_chat):
                            if msg.get("role") == "assistant" and msg.get("content", "").strip():
                                print("\nFound response in chat file:")
                                print("-" * 80)
                                print(msg.get("content"))
                                print("-" * 80)
                                response = msg.get("content")
                                break
                    except Exception as e:
                        print(f"Error reading updated chat file: {e}")
                
                # After response is generated, we can load and display the reasoning
                # that HindAI added to the chat history
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        updated_chat = json.load(f)
                    
                    # Find the reasoning process message
                    for msg in updated_chat:
                        if msg.get("role") == "system" and msg.get("message_type") == "reasoning_process":
                            # Extract just the reasoning part (after the prompt)
                            reasoning_text = msg.get("content", "")
                            if "'" in reasoning_text and "\n\n" in reasoning_text:
                                reasoning_text = reasoning_text.split("\n\n", 1)[1]
                            
                            print("\nReasoning process used for this response:")
                            print("-" * 80)
                            print(reasoning_text)
                            print("-" * 80)
                            break
                except Exception as e:
                    print(f"Note: Could not display reasoning: {e}")
                
            except Exception as e:
                print(f"Error getting response from HindAI: {e}")
        
        return chat_id, response
    except Exception as e:
        print(f"Error creating chat: {e}")
        return None, None

def select_language_interactive():
    """Interactively select a language from the available options"""
    languages = get_all_languages()
    
    if not languages:
        print("No language information available")
        return None, None
    
    print("\nSelect a language:")
    for i, lang in enumerate(sorted(languages, key=lambda x: x.get("name", "")), 1):
        print(f"{i}: {lang.get('name')} ({lang.get('code')})")
    
    print(f"{len(languages) + 1}: Skip language selection (use system default)")
    
    while True:
        try:
            choice = int(input("\nEnter your choice (number): "))
            if 1 <= choice <= len(languages):
                selected = sorted(languages, key=lambda x: x.get("name", ""))[choice - 1]
                return selected.get("code"), selected.get("name")
            elif choice == len(languages) + 1:
                return None, None
            else:
                print("Invalid choice, please try again.")
        except ValueError:
            print("Please enter a valid number.")
        except Exception as e:
            print(f"Error: {e}")
    
    return None, None

def main(username=None, chat_id=None, show_languages=False, initiate=False, message=None, 
         language_code=None, language_name=None, get_response=False):
    """
    Main function to either display user chats, a specific chat, initiate a new chat,
    or display language options
    
    Args:
        username (str, optional): Username to search for chats
        chat_id (str, optional): Specific chat ID to display
        show_languages (bool): Whether to display language information
        initiate (bool): Whether to initiate a new chat
        message (str, optional): Initial message for new chat
        language_code (str, optional): Language code for new chat
        language_name (str, optional): Language name for display
        get_response (bool): Whether to get an immediate response from HindAI
    """
    if show_languages:
        display_all_languages()
        return
    
    if not username:
        # Prompt for username if not provided
        username = input("Enter username: ").strip()
    
    if not username:
        print("Error: Username cannot be empty")
        return
    
    if initiate:
        if not message:
            message = input("Enter your initial message: ").strip()
        
        if not message:
            print("Error: Message cannot be empty")
            return
        
        # If language code not provided, and this is interactive mode, ask for it
        if not language_code and not sys.argv[1:]:
            use_language = input("Do you want to set a language preference? (y/n): ").strip().lower()
            if use_language in ['y', 'yes']:
                language_code, language_name = select_language_interactive()
            
        # Ask if user wants a response when in interactive mode
        if not sys.argv[1:] and has_hindai:
            get_response_input = input("Do you want to get an immediate response from HindAI? (y/n): ").strip().lower()
            get_response = get_response_input in ['y', 'yes']
        
        initiate_chat(username, message, language_code, language_name, get_response)
    elif chat_id:
        # Display a specific chat if chat ID is provided
        display_complete_chat(username, chat_id)
    else:
        # Otherwise display all chats for the user
        display_user_chats(username)

if __name__ == "__main__":
    # Check command line arguments
    if len(sys.argv) > 1:
        if sys.argv[1].lower() in ['--languages', '-l', 'languages']:
            main(show_languages=True)
        elif len(sys.argv) > 2 and sys.argv[1].lower() in ['--chat', '-c', 'chat']:
            # Format: python get_user_chats.py --chat <username> <chat_id>
            if len(sys.argv) > 3:
                main(username=sys.argv[2], chat_id=sys.argv[3])
            else:
                print("Error: Both username and chat_id are required with --chat option")
                print("Usage: python get_user_chats.py --chat <username> <chat_id>")
        elif len(sys.argv) > 2 and sys.argv[1].lower() in ['--initiate', '-i', 'initiate']:
            # Format: python get_user_chats.py --initiate <username> [message] [--lang <code>] [--respond]
            # Check for flags
            lang_code = None
            lang_name = None
            get_response = False
            message_parts = []
            i = 3
            
            # Process all arguments after username
            while i < len(sys.argv):
                if sys.argv[i].lower() in ['--lang', '-lang', '--language', '-language']:
                    if i + 1 < len(sys.argv):
                        lang_code = sys.argv[i + 1]
                        # Try to find the language name from the code
                        languages = get_all_languages()
                        for lang in languages:
                            if lang.get('code') == lang_code:
                                lang_name = lang.get('name')
                                break
                        i += 2  # Skip the next argument as it's the language code
                    else:
                        print("Error: Language code missing after --lang flag")
                        sys.exit(1)
                elif sys.argv[i].lower() in ['--respond', '-r', '--response']:
                    get_response = True
                    i += 1
                else:
                    message_parts.append(sys.argv[i])
                    i += 1
            
            message = ' '.join(message_parts) if message_parts else None
            main(username=sys.argv[2], initiate=True, message=message, 
                 language_code=lang_code, language_name=lang_name,
                 get_response=get_response)
        else:
            # Just username provided
            main(username=sys.argv[1])
    else:
        # If no arguments, show help
        print("Usage:")
        print("  python get_user_chats.py <username>                       - Show all chats for the user")
        print("  python get_user_chats.py --chat <username> <chat_id>      - Show a specific chat")
        print("  python get_user_chats.py --initiate <username> [msg] [--lang <code>] [--respond] - Start a new chat")
        print("  python get_user_chats.py --languages                      - Show all supported languages")
        
        # Ask what the user wants to do
        print("\nWhat would you like to do?")
        print("1: Show all chats for a user")
        print("2: Show a specific chat by ID")
        print("3: Initiate a new chat")
        print("4: Show supported languages")
        choice = input("Enter your choice (1-4): ").strip()
        
        if choice == '1':
            main()
        elif choice == '2':
            username = input("Enter username: ").strip()
            chat_id = input("Enter chat ID: ").strip()
            if username and chat_id:
                main(username=username, chat_id=chat_id)
            else:
                print("Error: Both username and chat ID are required.")
        elif choice == '3':
            username = input("Enter username: ").strip()
            message = input("Enter your initial message: ").strip()
            if username and message:
                main(username=username, initiate=True, message=message)
            else:
                print("Error: Both username and message are required.")
        elif choice == '4':
            main(show_languages=True)
        else:
            print("Invalid choice.")
