#!/usr/bin/env python3
"""
System diagnostics script for the HindAI API.
Run this script to verify that all components are properly installed and configured.
"""

import os
import sys
import importlib
import inspect

# Add directory containing this script to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
sys.path.insert(0, project_root)

def check_import(module_name):
    """Try to import a module and print its path if successful"""
    try:
        module = importlib.import_module(module_name)
        path = getattr(module, "__file__", "Unknown location")
        return True, path
    except ImportError as e:
        return False, str(e)
    except Exception as e:
        return False, f"Error: {str(e)}"

def main():
    print("\n=== HindAI API System Diagnostics ===\n")
    
    print(f"Current working directory: {os.getcwd()}")
    print(f"Script location: {__file__}")
    print(f"Python version: {sys.version}")
    print(f"Python executable: {sys.executable}")
    
    print("\n--- Python Path ---")
    for i, path in enumerate(sys.path, 1):
        print(f"{i}. {path}")
    
    print("\n--- Critical Module Check ---")
    modules_to_check = [
        "HindAI",
        "tools.resioning.reasioning",
        "agno",
        "fastapi",
        "django",
        "HindAI_Apis.agno_adapter",
    ]
    
    for module_name in modules_to_check:
        success, info = check_import(module_name)
        status = "✅ FOUND" if success else "❌ MISSING"
        print(f"{status}: {module_name} - {info}")
    
    # Check if reasioning.py is accessible directly
    resioning_path = os.path.join(project_root, "tools", "resioning", "reasioning.py")
    if os.path.exists(resioning_path):
        print(f"\n✅ reasioning.py file exists at {resioning_path}")
        
        # Check file content for indentation errors
        try:
            with open(resioning_path, "r") as f:
                content = f.read()
                compile(content, resioning_path, "exec")
                print("✅ reasioning.py compiles without syntax errors")
        except IndentationError as e:
            print(f"❌ IndentationError in reasioning.py: {e}")
            line_number = e.lineno
            # Show the problematic line and surrounding context
            with open(resioning_path, "r") as f:
                lines = f.readlines()
                start = max(0, line_number - 3)
                end = min(len(lines), line_number + 2)
                print("\nProblematic code section:")
                for i in range(start, end):
                    prefix = ">> " if i+1 == line_number else "   "
                    print(f"{prefix}Line {i+1}: {lines[i].rstrip()}")
        except Exception as e:
            print(f"❌ Error checking reasioning.py: {e}")
    else:
        print(f"\n❌ reasioning.py file not found at {resioning_path}")

    print("\n=== Diagnostics Complete ===")

if __name__ == "__main__":
    main()
