from agno.agent import Agent
from agno.models.openai.like import OpenAILike


def direct_response_search_and_solve(query, model, api_key, base_url):
    """Generate a structured solution based solely on the provided query using LLaMa."""
    agent = Agent(model=OpenAILike(
        id=model,
        api_key=api_key,
        base_url=base_url
    ))

    try:
        solution = agent.run(query).content.strip()
        return solution
    except Exception as e:
        return f"Error generating solution steps: {e}"
