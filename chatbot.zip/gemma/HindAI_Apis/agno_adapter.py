"""
Adapter module for agno library compatibility
This module provides patches and compatibility fixes for using Agno with HindAI
"""

import logging
import sys
import importlib
import json
from typing import Any, Dict, Optional, List

logger = logging.getLogger(__name__)

def monkey_patch_hindai():
    """
    Apply monkey patches to fix compatibility issues between Agno and HindAI
    """
    logger.info("Applying Agno compatibility patches")
    
    # Patch 1: Fix ChatCompletionAudio missing class if needed
    try:
        if 'openai' in sys.modules and 'openai.types.chat' in sys.modules:
            if not hasattr(sys.modules['openai.types.chat'], 'ChatCompletionAudio'):
                from dataclasses import dataclass
                
                @dataclass
                class ChatCompletionAudio:
                    id: str
                    data: bytes
                    expires_at: str
                    transcript: str
                
                sys.modules['openai.types.chat'].ChatCompletionAudio = ChatCompletionAudio
                logger.info("Patched missing ChatCompletionAudio class")
    except Exception as e:
        logger.error(f"Failed to patch ChatCompletionAudio: {e}")
    
    # Patch 2: Ensure the agno agent has the necessary methods
    try:
        from agno.agent import Agent
        
        # Add custom methods if they don't exist
        if not hasattr(Agent, 'get_history_context'):
            def get_history_context(self, max_tokens=1000):
                """Get formatted chat history suitable for context"""
                if not hasattr(self, 'messages') or not self.messages:
                    return ""
                
                formatted = []
                for msg in self.messages:
                    role = msg.get('role', 'unknown')
                    content = msg.get('content', '')
                    formatted.append(f"{role.capitalize()}: {content}")
                
                return "\n".join(formatted)
            
            Agent.get_history_context = get_history_context
            logger.info("Added get_history_context method to Agent")
    
    except ImportError:
        logger.warning("Agno not available, skipping Agent patches")
    except Exception as e:
        logger.error(f"Failed to patch Agent class: {e}")
        
    # Patch 3: Create adapter function for API formats
    if 'HindAI' in sys.modules:
        try:
            from HindAI import process_message_and_get_response
            
            # Add adapter for tool responses in HindAI
            # This function will be imported by HindAI to fix message formatting
            def format_tool_responses(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
                """
                Format tool response messages to ensure compatibility with OpenAI API
                
                Args:
                    messages: List of message objects that might contain tool responses
                    
                Returns:
                    List of properly formatted messages for API consumption
                """
                formatted_messages = []
                
                for msg in messages:
                    # Normal messages pass through unchanged
                    if msg.get("role") != "tool":
                        formatted_messages.append(msg)
                        continue
                    
                    # Format tool messages according to OpenAI API specification
                    formatted_tool_msg = {
                        "role": "tool",
                        "content": str(msg.get("content", "")),
                    }
                    
                    # Add tool_call_id if present
                    if "tool_call_id" in msg:
                        formatted_tool_msg["tool_call_id"] = msg["tool_call_id"]
                    
                    formatted_messages.append(formatted_tool_msg)
                
                return formatted_messages
            
            # Add this function to HindAI module
            sys.modules['HindAI'].format_tool_responses = format_tool_responses
            logger.info("Added format_tool_responses adapter to HindAI")
            
        except Exception as e:
            logger.error(f"Failed to add tool response adapter: {e}")
    
    # Log successful completion
    logger.info("Agno compatibility patches applied successfully")
    
    return True
