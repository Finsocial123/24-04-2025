// Handle URL form submission
document.getElementById('url-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const urlInput = document.getElementById('url-input').value.trim();
    const uploadStatus = document.getElementById('upload-status');
    const progressBar = document.getElementById('upload-progress');
    
    if (!urlInput) {
        uploadStatus.innerHTML = '<div class="alert alert-danger">Please enter a URL</div>';
        return;
    }
    
    // Show progress indicator
    progressBar.style.display = 'block';
    progressBar.querySelector('.progress-bar').style.width = '50%';
    uploadStatus.innerHTML = '<div class="alert alert-info">Processing URL...</div>';
    
    // Send the URL to the server
    fetch('/upload-from-url', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ url: urlInput }),
        credentials: 'include'
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(data => {
                throw new Error(data.detail || 'Unknown error occurred');
            });
        }
        return response.json();
    })
    .then(data => {
        // Update progress
        progressBar.querySelector('.progress-bar').style.width = '100%';
        
        // Display success message
        uploadStatus.innerHTML = '<div class="alert alert-success">File processed successfully!</div>';
        
        // Store the session ID
        sessionId = data.session_id;
        console.log('Session ID stored:', sessionId);
        
        // Show query section
        document.getElementById('query-section').style.display = 'block';
        
        // Update content type indicators
        updateContentTypeDisplay(data.file_type);
        
        // After a short delay, hide the progress bar
        setTimeout(() => {
            progressBar.style.display = 'none';
        }, 1500);
    })
    .catch(error => {
        // Update progress
        progressBar.style.display = 'none';
        
        // Show error message
        uploadStatus.innerHTML = `<div class="alert alert-danger">Error: ${error.message}</div>`;
    });
});

// Helper function to update content type display
function updateContentTypeDisplay(fileType) {
    const contentTypeText = document.getElementById('content-type-text');
    const contentTypeBadge = document.getElementById('content-type-badge');
    
    if (fileType === 'image') {
        contentTypeText.textContent = 'Image';
        contentTypeBadge.innerHTML = '<span class="badge bg-info">Image File</span>';
    } else if (fileType === 'media') {
        contentTypeText.textContent = 'Audio/Video';
        contentTypeBadge.innerHTML = '<span class="badge bg-info">Media File</span>';
    } else {
        contentTypeText.textContent = 'Document';
        contentTypeBadge.innerHTML = '<span class="badge bg-info">Document</span>';
    }
}