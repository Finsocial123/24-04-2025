"""
Demo Script for LlamaIndex API Client

This script demonstrates how to use the LlamaIndex API client
to interact with the FastAPI server from external applications.
"""

from api_client import LlamaIndexClient
import os
import sys
import argparse

def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="LlamaIndex API Client Demo")
    parser.add_argument("--url", default="http://localhost:5000", 
                        help="Base URL of the LlamaIndex API server")
    parser.add_argument("--file", required=True, 
                        help="Path to the file to upload and analyze")
    parser.add_argument("--question", default="What is this document about?", 
                        help="Question to ask about the document")
    parser.add_argument("--session", 
                        help="Existing session ID (skips file upload if provided)")
    
    args = parser.parse_args()
    
    # Create the client
    client = LlamaIndexClient(base_url=args.url)
    print(f"Connecting to LlamaIndex API at: {args.url}")
    
    try:
        # First check if the API is healthy
        health = client.check_api_health()
        print(f"API Health Status: {'Healthy' if health.get('status') == 'healthy' else 'Unhealthy'}")
        
        # Use existing session or upload a new file
        session_id = args.session
        if session_id:
            print(f"Using existing session: {session_id}")
            client.session_id = session_id
            
            # Verify the session is active
            status = client.check_session_status(session_id)
            if status.get('status') != 'active':
                print(f"Error: Session {session_id} is not active")
                return 1
            
            print("Session is active and ready for questions")
        else:
            # Upload the file
            if not os.path.exists(args.file):
                print(f"Error: File not found: {args.file}")
                return 1
            
            print(f"Uploading file: {args.file}")
            result = client.upload_file(args.file)
            
            session_id = result.get('session_id')
            print(f"Upload successful. Session ID: {session_id}")
            print(f"File type: {result.get('file_type', 'unknown')}")
        
        # Ask a question about the content
        print(f"\nAsking question: '{args.question}'")
        print("Waiting for response...")
        
        response = client.ask_question(args.question)
        
        print("\n----- ANSWER -----")
        print(response.get('response', 'No response received'))
        print("------------------\n")
        
        # Print session ID for future use
        print(f"Session ID for future queries: {client.session_id}")
        print("You can reuse this session ID with --session parameter")
        
        return 0
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return 1

if __name__ == "__main__":
    sys.exit(main())