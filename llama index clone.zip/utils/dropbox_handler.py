import re
import aiohttp
import os
import logging
import mimetypes
from typing import Dict

logger = logging.getLogger(__name__)

def get_content_type(filename: str) -> str:
    """Get content type based on file extension"""
    content_type, _ = mimetypes.guess_type(filename)
    return content_type or 'application/octet-stream'

def is_valid_dropbox_url(url: str) -> bool:
    """Accept any URL containing dropboxusercontent.com"""
    return True  # Accept all URLs, let the download function handle errors

def get_filename_from_url(url):
    """Extract filename from Dropbox URL"""
    try:
        # Updated pattern to match any file type
        pattern = r'/([^/]+_[^/]+\.[a-zA-Z0-9]+)\?'  # Matches timestamp_filename.extension
        match = re.search(pattern, url)
        
        if match:
            filename = match.group(1)
            # Remove timestamp prefix if present
            filename = re.sub(r'^\d+_', '', filename)
            return filename.replace("%20", " ")
        
        # Fallback: Extract just the last part of the path
        parts = url.split('/')
        if parts:
            last_part = parts[-1].split('?')[0]
            if '.' in last_part:
                return last_part
        
        return "downloaded_file"
    except Exception as e:
        logger.error(f"Error extracting filename: {str(e)}")
        return "downloaded_file"

def get_headers_for_file(filename: str) -> Dict[str, str]:
    """Get appropriate headers based on file type"""
    content_type = get_content_type(filename)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': '*/*'
    }
    
    # Add specific headers based on content type
    if (content_type):
        headers['Accept'] = content_type
    
    return headers

async def download_file_from_dropbox(url: str, output_path: str) -> bool:
    """Download file from Dropbox URL with improved file type handling"""
    try:
        # Ensure output directory exists
        output_dir = os.path.dirname(output_path)
        os.makedirs(output_dir, exist_ok=True)
        
        # Get filename and appropriate headers
        filename = get_filename_from_url(url)
        headers = get_headers_for_file(filename)
        
        logger.info(f"Downloading to: {output_path}")
        temp_path = output_path + '.tmp'
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, allow_redirects=True) as response:
                if response.status != 200:
                    logger.error(f"Download failed with status {response.status}")
                    return False
                
                # Save to temporary file first
                try:
                    with open(temp_path, 'wb') as f:
                        while True:
                            chunk = await response.content.read(8192)
                            if not chunk:
                                break
                            f.write(chunk)
                    
                    # Move temp file to final location
                    os.replace(temp_path, output_path)
                    logger.info(f"File downloaded and saved to: {output_path}")
                    return True
                    
                except Exception as write_error:
                    logger.error(f"Error writing file: {str(write_error)}")
                    if os.path.exists(temp_path):
                        os.remove(temp_path)
                    return False
        
    except Exception as e:
        logger.error(f"Download error: {str(e)}")
        if os.path.exists(temp_path):
            os.remove(temp_path)
        return False
