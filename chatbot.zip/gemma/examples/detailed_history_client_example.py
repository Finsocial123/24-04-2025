import requests
import json
import sys

def get_detailed_history(username: str, chat_id: str):
    """
    Fetch detailed chat history from the API including prompts, reasoning, and responses
    
    Args:
        username: User's name
        chat_id: Chat ID to fetch history for
        
    Returns:
        Dict containing the detailed chat history
    """
    base_url = "http://localhost:8000"  # Update with your API URL
    
    # Prepare the request data
    data = {
        "username": username,
        "chat_id": chat_id
    }
    
    # Send request to get detailed history
    print(f"Fetching detailed history for chat {chat_id}...")
    endpoint = f"{base_url}/chat/detailed-history"
    response = requests.post(endpoint, json=data)
    
    if response.status_code != 200:
        print(f"Error: Received status code {response.status_code}")
        print(response.text)
        return None
    
    # Parse the response
    history = response.json()
    
    # Display the detailed history
    print(f"\nDetailed Chat History for {chat_id}\n")
    print("=" * 50)
    
    for i, msg in enumerate(history.get("messages", [])):
        print(f"Turn {i+1} - {msg.get('timestamp')}")
        print("\nUser Prompt:")
        print(msg.get("prompt"))
        
        if msg.get("reasoning"):
            print("\nReasoning Process:")
            print(msg.get("reasoning"))
        
        if msg.get("response"):
            print("\nFinal Response:")
            print(msg.get("response"))
        
        print("\n" + "=" * 50)
    
    return history

def save_history_to_file(history, filename):
    """Save the detailed history to a JSON file"""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(history, f, indent=2)
        print(f"History saved to {filename}")
    except Exception as e:
        print(f"Error saving history: {e}")

if __name__ == "__main__":
    # Check arguments
    if len(sys.argv) < 3:
        print("Usage: python detailed_history_client_example.py <username> <chat_id> [output_file]")
        sys.exit(1)
    
    username = sys.argv[1]
    chat_id = sys.argv[2]
    output_file = sys.argv[3] if len(sys.argv) > 3 else None
    
    # Get detailed history
    history = get_detailed_history(username, chat_id)
    
    # Save to file if specified
    if history and output_file:
        save_history_to_file(history, output_file)
