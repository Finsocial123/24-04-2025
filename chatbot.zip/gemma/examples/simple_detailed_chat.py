#!/usr/bin/env python
# Simple client to get detailed chat history (no dependencies)

import requests
import json
import sys

def get_detailed_chat_history(username, chat_id, base_url="http://localhost:8000"):
    """
    Simple function to fetch and display detailed chat history
    
    Args:
        username: Username who owns the chat
        chat_id: Chat ID to fetch
        base_url: Base URL for the API
    """
    endpoint = f"{base_url}/chat/detailed-history"
    data = {"username": username, "chat_id": chat_id}
    
    print(f"Requesting detailed chat history for chat {chat_id}...")
    
    try:
        response = requests.post(endpoint, json=data)
        
        if response.status_code != 200:
            print(f"Error {response.status_code}: {response.text}")
            return
            
        history = response.json()
        
        # Print the chat information
        print("\n" + "=" * 60)
        print(f"DETAILED CHAT HISTORY FOR {chat_id}")
        print("=" * 60)
        
        messages = history.get("messages", [])
        if not messages:
            print("No messages found in this chat.")
            return
            
        # Print each turn in the conversation
        for i, msg in enumerate(messages):
            print(f"\n--- TURN {i+1} ---")
            print("\nUSER PROMPT:")
            print(msg.get("prompt", ""))
            
            if msg.get("reasoning"):
                print("\nREASONING:")
                print(msg.get("reasoning", ""))
            
            if msg.get("response"):
                print("\nFINAL RESPONSE:")
                print(msg.get("response", ""))
                
            print("\n" + "-" * 60)
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python simple_detailed_chat.py <username> <chat_id> [api_url]")
        sys.exit(1)
    
    username = sys.argv[1]
    chat_id = sys.argv[2]
    base_url = sys.argv[3] if len(sys.argv) > 3 else "http://localhost:8000"
    
    get_detailed_chat_history(username, chat_id, base_url)
