"""
LlamaIndex API Client Library

A simple client library for interacting with the LlamaIndex FastAPI endpoints.
This client handles file uploads, question answering, and session management.
"""

import requests
import os
import json
from typing import Dict, Any, Optional, Union, BinaryIO
import mimetypes
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class LlamaIndexClient:
    """Client library for interfacing with the LlamaIndex API endpoints."""
    
    def __init__(self, base_url: str = "http://localhost:5000"):
        """
        Initialize the client with the API base URL.
        
        Args:
            base_url: The base URL of the API server
        """
        self.base_url = base_url.rstrip('/')
        self.session_id: Optional[str] = None
        
    def upload_file(self, filepath: str) -> Dict[str, Any]:
        """
        Upload a file to the API and process it.
        
        Args:
            filepath: Path to the file to upload
            
        Returns:
            Dict containing response data including session_id
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")
        
        filename = os.path.basename(filepath)
        
        # Determine content type
        content_type = mimetypes.guess_type(filepath)[0]
        if content_type is None:
            content_type = 'application/octet-stream'
            
        logger.info(f"Uploading file: {filename} ({content_type})")
        
        try:
            with open(filepath, 'rb') as file:
                files = {'file': (filename, file, content_type)}
                response = requests.post(
                    f"{self.base_url}/upload",
                    files=files
                )
                response.raise_for_status()
                
                result = response.json()
                self.session_id = result.get('session_id')
                
                return result
        except requests.RequestException as e:
            logger.error(f"Upload error: {str(e)}")
            if hasattr(e.response, 'text'):
                logger.error(f"Response: {e.response.text}")
            raise
    
    def ask_question(self, question: str, session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Ask a question about the uploaded content.
        
        Args:
            question: The question to ask
            session_id: Optional session ID. If not provided, uses the stored session ID
                        from the last upload
            
        Returns:
            Dict containing the response
        """
        # Use the provided session_id or fall back to the stored one
        session_id = session_id or self.session_id
        
        if not session_id:
            raise ValueError("No session ID available. Please upload a file first or provide a session ID.")
        
        logger.info(f"Asking question with session ID: {session_id}")
        
        try:
            response = requests.post(
                f"{self.base_url}/query",
                json={
                    "question": question,
                    "session_id": session_id
                }
            )
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"Query error: {str(e)}")
            if hasattr(e, 'response') and hasattr(e.response, 'text'):
                logger.error(f"Response: {e.response.text}")
            raise
    
    def check_session_status(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Check if a session is active.
        
        Args:
            session_id: Optional session ID. If not provided, uses the stored session ID
            
        Returns:
            Dict containing session status information
        """
        session_id = session_id or self.session_id
        
        if not session_id:
            raise ValueError("No session ID available. Please provide a session ID.")
        
        try:
            response = requests.get(
                f"{self.base_url}/api/session/{session_id}/status"
            )
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"Session status check error: {str(e)}")
            if hasattr(e, 'response') and hasattr(e.response, 'text'):
                logger.error(f"Response: {e.response.text}")
            raise
    
    def check_api_health(self) -> Dict[str, Any]:
        """
        Check if the API is healthy and get version information.
        
        Returns:
            Dict containing health status information
        """
        try:
            response = requests.get(f"{self.base_url}/api/health")
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"Health check error: {str(e)}")
            if hasattr(e, 'response') and hasattr(e.response, 'text'):
                logger.error(f"Response: {e.response.text}")
            raise

# Example usage
if __name__ == "__main__":
    # Create a client
    client = LlamaIndexClient("http://localhost:5000")
    
    # Check API health
    health = client.check_api_health()
    print(f"API Health: {health}")
    
    # Example: Upload a PDF file
    try:
        # Replace with an actual file path
        result = client.upload_file("example.pdf")
        print(f"Upload successful: {result}")
        
        # Ask a question about the uploaded content
        response = client.ask_question("What is this document about?")
        print(f"Answer: {response['response']}")
    except Exception as e:
        print(f"Error: {str(e)}")