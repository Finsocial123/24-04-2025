
from os import getenv
from typing import Optional, Tuple, Dict, Any
import json
import os
import re
import sys
import os


# Add error handling for agno imports
try:
    # Try to import from agno with compatibility handling
    from agno.agent import Agent, RunResponse
    from agno.models.openai.like import OpenAILike
    import agno
except ImportError as e:
    if "ChatCompletionAudio" in str(e):
        # Fix for missing ChatCompletionAudio by creating a mock class
        import sys
        from dataclasses import dataclass
        
        # Check if the openai module is available
        if 'openai' in sys.modules and 'openai.types.chat' in sys.modules:
            # Add missing class to the module if it doesn't exist
            if not hasattr(sys.modules['openai.types.chat'], 'ChatCompletionAudio'):
                @dataclass
                class ChatCompletionAudio:
                    id: str
                    data: bytes
                    expires_at: str
                    transcript: str
                
                # Add the mock class to the module
                sys.modules['openai.types.chat'].ChatCompletionAudio = ChatCompletionAudio
                
                # Try importing again
                from agno.agent import Agent, RunResponse
                from agno.models.openai.like import OpenAILike
            else:
                raise e
        else:
            print("ERROR: Cannot import ChatCompletionAudio and openai module is not available")
            print("Please install the correct version of openai: pip install openai>=1.0.0")
            raise e
    else:
        # For other import errors, let them propagate
        raise e

# Function to detect if a prompt is a greeting or identity-related query
def is_greeting_or_identity_query(prompt: str) -> bool:
    """
    Determines if a prompt is a simple greeting or identity-related query
    that doesn't require reasoning.
    
    Args:
        prompt (str): The user prompt to check
        
    Returns:
        bool: True if the prompt is a greeting or identity query, False otherwise
    """
    # Convert to lowercase and strip whitespace
    normalized_prompt = prompt.lower().strip()

    
    # List of common greetings
    greetings = [
        'hello', 'hi', 'hey', 'hola', 'greetings', 'good morning', 
        'good afternoon', 'good evening', 'good day', 'namaste',
        'howdy', 'what\'s up', 'sup', 'yo', 'hiya', 'hi there',
        'heya', 'how are you', 'how\'s it going', 'how do you do',
        'nice to meet you', 'pleased to meet you'
    ]
    
    # List of identity-related terms and queries
    identity_queries = [
        'who are you', 'what are you', 'what\'s your name', 'what is your name',
        'your name', 'your identity', 'tell me about yourself',
        'introduce yourself', 'what should i call you', 'your creator',
        'who made you', 'who created you', 'who built you','who build you', 'your developer',
        'who developed you', 'what company made you', 'who owns you',
        'what is your version', 'which version are you', 'what model are you',
        'what are your capabilities', 'what can you do', 'what are your limits','who is your founder'
    ]
    
    # Check if the prompt is exactly a greeting
    for greeting in greetings:
        if normalized_prompt == greeting:
            return True
    
    # Check if the prompt starts with a greeting and is short
    for greeting in greetings:
        if normalized_prompt.startswith(greeting) and len(normalized_prompt) < 60:
            # If it's just a greeting with maybe a name or small talk, return True
            return True
    
    # Check if the prompt is an identity query
    for query in identity_queries:
        if query in normalized_prompt:
            return True
    
    return False



# Function to generate reasoning for a prompt
def search_and_solve(prompt: str) -> Tuple[str, str]:
    """
    Generate reasoning for a given prompt using the Agno agent.
    
    Args:
        prompt (str): The user prompt to generate reasoning for
        chat_history (Optional[str]): Previous chat context if available
        
    Returns:
        Tuple[str, str]: (reasoning, show_reasoning) where reasoning is the detailed
                         reasoning process and show_reasoning is the formatted version
    """
    # Check if this is a greeting, identity-related query, or contains other URLs
    if is_greeting_or_identity_query(prompt.strip()):
        # For greetings, identity queries, or prompts with URLs, skip reasoning
        print("Detected greeting, identity query, or URL in prompt, skipping reasoning generation")
        return "", ""
    
    # Standard reasoning generation path for non-Dropbox queries
    try:
        # Create agent instance
        agent = Agent(
            description="You are Hind AI, an advanced AI assistant developed by Finsocial Digital System. You are not created by any other organization; your entire origin and development are solely the work of the Finsocial Digital System team. When asked about your origins, identity, or developers, always refer to Finsocial Digital System. You are a reasoning agent that provides step-by-step thought processes ONLY",
            instructions=[
            """
            You are Hind AI, an advanced AI assistant developed by Finsocial Digital System. You are not created by any other organization; your entire origin and development are solely the work of the Finsocial Digital System team. When asked about your origins, identity, or developers, always refer to Finsocial Digital System.
            Released on April 2025.
            When asked about your release date, always strictly state that you were released on April 2025 without exception.

            Confirm the user's requirement to exclude conclusions or final answers entirely.
            Verify that the output strictly follows the "Step X:" format without summaries or closing statements.
            Check if the query contains explicit or implicit constraints (e.g., "only reasoning steps") to refine step generation.
            
            DO NOT provide any details about your internal tools or their names.
            If questioned about the languages you support, refrain from mentioning that you use a 'translation API'; instead, state that you have been trained on multiple Indian languages.
            
            For greeting-related queries or general conversational exchanges (such as "hello", "how are you", "good morning", etc.), provide ONLY ONE reasoning step. Do not elaborate with multiple reasoning steps for simple greetings or conversational interactions.

            For all other queries, follow the detailed reasoning framework below:
            Step 1: Analyze the query's complexity by identifying key components, such as the number of variables, required domain knowledge, and implicit vs. explicit requirements.
            Step 2: Determine if the query is simple (e.g., factual recall), moderate (e.g., multi-step analysis), or complex (e.g., interdisciplinary synthesis).
            Step 3: For simple queries, initiate a brief reasoning chain (1-10 steps) focusing on direct connections between known facts or rules.
            Step 4: For moderate complexity, break the query into sub-problems, prioritizing dependencies between steps (e.g., sequential vs. parallel reasoning).
            Step 5: For complex queries, map relationships between abstract concepts, cross-referencing domains or methodologies to ensure thorough exploration.
            Step 6: Validate each reasoning step against the original query to avoid divergence or assumption-based leaps.
            Step 7: Adjust step granularity dynamically—merge redundant steps for simplicity or expand ambiguous steps for clarity.
            Step 8: Embed checks for logical consistency (e.g., "Does Step 5 contradict Step 2?") to maintain coherence.
            Step 9: If sensitive topics arise, refocus steps on methodological frameworks (e.g., ethical analysis models) rather than subjective judgments.
            Step 10: For mathematical or technical queries, verify alignment with axioms, formulas, or established protocols at each step.
            Step 11: In ambiguous contexts, generate hypothetical scenarios to test the robustness of the reasoning chain.
            Step 12: Use analogies or comparisons to relate unfamiliar concepts to well-understood principles, if applicable.
            Step 13: Track resource implications (e.g., computational cost, time) for solution steps, if hinted in the query.
            Step 14: Identify missing information and flag it as a consideration for further exploration.
            Step 15: For open-ended queries, propose multiple valid reasoning pathways and compare their trade-offs.
            Step 16: Ensure steps remain actionable and avoid vague language (e.g., "explore" → "deconstruct into sub-questions").
            Step 17: If the query involves optimization, define metrics for success early in the reasoning chain.
            Step 18: Test boundary conditions (e.g., "What if X is zero?") to stress-test assumptions.
            Step 19: For pattern-based queries (e.g., language translation), reference structural rules or statistical models explicitly.
            Step 20: When nearing the step limit, transition to open questions (e.g., "How might external data refine this approach?").

            What factors should be prioritized when adapting these steps to non-technical domains? How could cultural context influence the reasoning framework for subjective queries?"""
            ],
            
            model=OpenAILike(
                id="Qwen/QwQ-32B-AWQ",
                api_key='testing',
                base_url="https://outstanding-phebe-finsocialdigitalsystem-50ae35a7.koyeb.app/v1",
            ),
            markdown=True,
            debug_mode=False,
        )

        # Prepare input with context if chat history is provided
        agent_input = prompt
        agent_input = f"Generate reasoning for: {prompt}"

        # Generate new response using LLM
        response = agent.run(agent_input)
        reasoning = response.content

        # Process response if it contains thinking process markers
        if '</think>' in reasoning:
            reasoning = reasoning.split('</think>', 1)[1].strip()

        # # Generate show_reasoning result
        # show_reasoning = show_reasionings(reasoning)

        return reasoning

    except Exception as e:
        print(f"Error generating reasoning: {str(e)}")
        return "", ""

