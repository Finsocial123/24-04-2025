import requests
import json
import time
import sys

def send_chat_request(username: str, message: str, chat_id: str = None, language_code: str = "eng_Latn", language_name: str = "English"):
    """
    Send a chat request to Hind AI API and handle two-step response process
    
    Args:
        username: User's name
        message: User's message
        chat_id: Optional chat ID (None for new chat)
        language_code: Language code (default: English)
        language_name: Language name (default: English)
        
    Returns:
        Dict containing both reasoning and final response
    """
    base_url = "http://localhost:8000"  # Update with your API URL
    
    # Prepare the request data
    data = {
        "username": username,
        "language_code": language_code,
        "language_name": language_name,
        "message": message
    }
    
    # Decide whether to initiate or continue chat
    if chat_id:
        # Continue existing chat
        data["chat_id"] = chat_id
        endpoint = f"{base_url}/chat/continue"
    else:
        # Initiate new chat
        endpoint = f"{base_url}/chat/initiate"
    
    # Send the initial request to get reasoning
    print("Getting reasoning...")
    initial_response = requests.post(endpoint, json=data)
    
    if initial_response.status_code != 200:
        print(f"Error: Received status code {initial_response.status_code}")
        print(initial_response.text)
        return None
    
    # Parse the initial response to get reasoning and response_id
    reasoning_data = initial_response.json()
    response_id = reasoning_data.get("response_id")
    chat_id = reasoning_data.get("chat_id")  # Get the chat ID (important for new chats)
    reasoning = reasoning_data.get("reasoning", "")
    
    # Display the reasoning
    print("\n--- Reasoning Process ---")
    print(reasoning)
    print("--- End of Reasoning ---\n")
    
    # Prepare to poll for the final response
    print("Waiting for final response...")
    
    # Data for checking response status
    status_data = {"response_id": response_id}
    status_endpoint = f"{base_url}/chat/response-status"
    
    # Poll for the final response
    max_retries = 30  # Maximum number of retries
    retry_delay = 1   # Initial delay between retries in seconds
    
    for i in range(max_retries):
        # Wait before checking status
        time.sleep(retry_delay)
        
        # Check response status
        status_response = requests.post(status_endpoint, json=status_data)
        
        if status_response.status_code != 200:
            print(f"Error checking status: {status_response.status_code}")
            print(status_response.text)
            continue
        
        response_status = status_response.json()
        
        # If response is ready, display it and return
        if response_status.get("status") == "completed":
            final_response = response_status.get("response", "")
            print("\n--- Final Response ---")
            print(final_response)
            
            return {
                "chat_id": chat_id,
                "reasoning": reasoning,
                "response": final_response
            }
        
        # Increase delay slightly with each retry (up to 5 seconds max)
        retry_delay = min(retry_delay * 1.5, 5)
        print(f"Response still processing... (attempt {i+1})")
    
    print("Timeout waiting for response.")
    return {
        "chat_id": chat_id,
        "reasoning": reasoning,
        "response": "Timeout waiting for response."
    }

if __name__ == "__main__":
    # Get username from command line or use default
    username = sys.argv[1] if len(sys.argv) > 1 else "test_user"
    
    print(f"Hind AI Chat API Client Example (User: {username})")
    print("Type 'exit' to quit.")
    
    chat_id = None  # Start with a new chat
    
    while True:
        # Get user input
        message = input("\nYou: ")
        
        if message.lower() == 'exit':
            print("Goodbye!")
            break
        
        # Send the message to the API
        result = send_chat_request(username, message, chat_id)
        
        if result:
            # Save the chat ID for next messages
            chat_id = result["chat_id"]
